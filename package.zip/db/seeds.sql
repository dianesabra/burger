INSERT INTO burgers (burger_name, devoured) VALUES ('Cheeseburger', true);
INSERT INTO burgers (burger_name, devoured) VALUES ('Bacon Cheeseburger', false);